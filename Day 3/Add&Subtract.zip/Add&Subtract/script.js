var num = 0;

function add() {
	num++;
	document.getElementById("h1Tag").innerHTML = num;
}


function subtract() {
	num--;
	document.getElementById("h1Tag").innerHTML = num;
}